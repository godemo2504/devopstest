# 🔍 Proxmox Monitor + iDRAC

Application de **supervision Proxmox VE** et **hardware Dell PowerEdge (iDRAC)** en Python.

## Fonctionnalités

- **Cluster Proxmox** : nœuds, VMs/LXC, stockages, réseau, vue globale
- **Alertes** : CPU, RAM, disque, réseau, nœud offline → ntfy / Discord / Email
- **Historique** : graphiques Plotly (CPU, RAM, disque, réseau)
- **iDRAC / Redfish** : santé, températures, fans, PSU, conso, disques, logs SEL
- **Alertes hardware** : offline, health, temp, PSU, fan, disk, logs critiques
- **CLI** + **interface web Streamlit** + **collecteur** d’arrière-plan

## Arborescence

```
proxmox-monitor/
├── core.py              # Client Proxmox API + historique SQLite
├── alerts.py            # Alertes (ntfy, Discord, Email, iDRAC)
├── idrac.py             # Client Redfish Dell iDRAC + SEL logs
├── streamlit_app.py     # Interface web (dashboard)
├── proxmox_monitor.py   # Interface CLI (terminal)
├── collector.py         # Collecte périodique + alertes
├── requirements.txt
├── .env.example         # Modèle de configuration
├── .gitignore
└── README.md
```

## Prérequis

- Python **3.9+**
- Accès réseau au(x) nœud(s) Proxmox (port **8006**)
- Optionnel : accès HTTPS aux iDRAC (Redfish)
- Compte Proxmox avec API Token (recommandé) ou mot de passe
- Compte iDRAC en lecture seule

## Installation

```bash
# 1. Décompresser / cloner
cd proxmox-monitor

# 2. Environnement virtuel
python3 -m venv venv
source venv/bin/activate          # Linux / macOS
# venv\Scripts\activate           # Windows

# 3. Dépendances
pip install -r requirements.txt

# 4. Configuration
cp .env.example .env
nano .env   # ou votre éditeur
```

## Configuration (`.env`)

### Proxmox

```env
PROXMOX_HOST=192.168.1.10
PROXMOX_PORT=8006
PROXMOX_USER=root@pam
PROXMOX_TOKEN_NAME=monitoring
PROXMOX_TOKEN_VALUE=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
PROXMOX_VERIFY_SSL=false
```

Créer un token : **Datacenter → Permissions → API Tokens → Add**.

### Alertes Proxmox

```env
ALERT_CPU_THRESHOLD=85
ALERT_RAM_THRESHOLD=90
ALERT_DISK_THRESHOLD=90
ALERT_NET_IN_MBPS=800
ALERT_NET_OUT_MBPS=400
ALERT_COOLDOWN_MINUTES=15
```

### Canaux d’alerte

```env
# ntfy (simple)
NTFY_ENABLED=true
NTFY_URL=https://ntfy.sh/mon-topic-proxmox

# Discord
DISCORD_ENABLED=false
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/...

# Email
EMAIL_ENABLED=false
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=...
SMTP_PASSWORD=...
EMAIL_TO=admin@example.com
```

### Dell iDRAC

```env
IDRAC_HOSTS=192.168.1.101,192.168.1.102,192.168.1.103
IDRAC_USER=root
IDRAC_PASSWORD=calvin
IDRAC_VERIFY_SSL=false

IDRAC_ALERTS_ENABLED=true
ALERT_IDRAC_OFFLINE=true
ALERT_IDRAC_HEALTH=true
ALERT_IDRAC_TEMP=true
ALERT_IDRAC_PSU=true
ALERT_IDRAC_FAN=true
ALERT_IDRAC_DISK=true
ALERT_IDRAC_LOGS=true
ALERT_TEMP_CELSIUS=75
```

## Lancement

### Interface web (recommandée)

```bash
source venv/bin/activate
streamlit run streamlit_app.py
```

Ouvrir **http://localhost:8501**

Onglets : Vue Cluster, Nœuds, Machines, Réseau, Stockage, **Hardware iDRAC**, Historique.

### Collecteur d’arrière-plan (recommandé)

Pour historique + alertes même sans navigateur ouvert :

```bash
source venv/bin/activate
python collector.py
```

Intervalle : `COLLECT_INTERVAL` (défaut 30 s).

### Mode CLI

```bash
python proxmox_monitor.py           # une fois
python proxmox_monitor.py --live    # rafraîchissement continu
python proxmox_monitor.py --live --interval 10
```

## Production (exemple systemd)

```ini
# /etc/systemd/system/proxmox-collector.service
[Unit]
Description=Proxmox + iDRAC collector
After=network.target

[Service]
Type=simple
User=monitor
WorkingDirectory=/opt/proxmox-monitor
Environment=PATH=/opt/proxmox-monitor/venv/bin
ExecStart=/opt/proxmox-monitor/venv/bin/python collector.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now proxmox-collector
```

Pour Streamlit en service, utilisez un reverse proxy (nginx) + `streamlit run --server.address 0.0.0.0`.

## Sécurité

- Préférez un **API Token** Proxmox avec rôle `PVEAuditor`
- Compte iDRAC **lecture seule**
- Ne commitez jamais le fichier `.env`
- Activez `VERIFY_SSL=true` si certificats valides

## Licence

MIT
