#!/usr/bin/env python3
"""
Module d'alertes : ntfy, Discord, Email
"""

import os
import smtplib
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Set
from pathlib import Path
import json

import requests
from dotenv import load_dotenv

load_dotenv()


class AlertManager:
    def __init__(self):
        self.cpu_threshold = float(os.getenv("ALERT_CPU_THRESHOLD", "85"))
        self.ram_threshold = float(os.getenv("ALERT_RAM_THRESHOLD", "90"))
        self.disk_threshold = float(os.getenv("ALERT_DISK_THRESHOLD", "90"))
        # Seuils réseau en Mb/s (mégabits par seconde)
        self.net_in_threshold = float(os.getenv("ALERT_NET_IN_MBPS", "0"))   # 0 = désactivé
        self.net_out_threshold = float(os.getenv("ALERT_NET_OUT_MBPS", "0"))
        self.cooldown_minutes = int(os.getenv("ALERT_COOLDOWN_MINUTES", "15"))

        # État des dernières alertes (pour le cooldown)
        self._last_alerts: Dict[str, float] = {}
        self._state_file = Path("alert_state.json")
        self._load_state()

        # Canaux
        self.ntfy_enabled = os.getenv("NTFY_ENABLED", "false").lower() == "true"
        self.ntfy_url = os.getenv("NTFY_URL", "")
        self.ntfy_token = os.getenv("NTFY_TOKEN")

        self.discord_enabled = os.getenv("DISCORD_ENABLED", "false").lower() == "true"
        self.discord_webhook = os.getenv("DISCORD_WEBHOOK_URL", "")

        self.email_enabled = os.getenv("EMAIL_ENABLED", "false").lower() == "true"
        self.smtp_host = os.getenv("SMTP_HOST")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.smtp_user = os.getenv("SMTP_USER")
        self.smtp_password = os.getenv("SMTP_PASSWORD")
        self.email_from = os.getenv("EMAIL_FROM")
        self.email_to = os.getenv("EMAIL_TO")

    def _load_state(self):
        if self._state_file.exists():
            try:
                self._last_alerts = json.loads(self._state_file.read_text())
            except Exception:
                self._last_alerts = {}

    def _save_state(self):
        try:
            self._state_file.write_text(json.dumps(self._last_alerts))
        except Exception:
            pass

    def _can_send(self, key: str) -> bool:
        now = time.time()
        last = self._last_alerts.get(key, 0)
        if now - last < self.cooldown_minutes * 60:
            return False
        self._last_alerts[key] = now
        self._save_state()
        return True


    def check_idrac_and_alert(self, idrac_snapshots: list) -> List[str]:
        """Vérifie la santé hardware iDRAC et envoie les alertes."""
        if os.getenv("IDRAC_ALERTS_ENABLED", "true").lower() not in ("1", "true", "yes"):
            return []

        from idrac import check_idrac_alerts

        temp_th = float(os.getenv("ALERT_TEMP_CELSIUS", "0"))
        raw = check_idrac_alerts(idrac_snapshots, temp_threshold=temp_th)

        # Filtres optionnels
        enable_offline = os.getenv("ALERT_IDRAC_OFFLINE", "true").lower() in ("1", "true", "yes")
        enable_health = os.getenv("ALERT_IDRAC_HEALTH", "true").lower() in ("1", "true", "yes")
        enable_temp = os.getenv("ALERT_IDRAC_TEMP", "true").lower() in ("1", "true", "yes")
        enable_psu = os.getenv("ALERT_IDRAC_PSU", "true").lower() in ("1", "true", "yes")
        enable_fan = os.getenv("ALERT_IDRAC_FAN", "true").lower() in ("1", "true", "yes")
        enable_disk = os.getenv("ALERT_IDRAC_DISK", "true").lower() in ("1", "true", "yes")
        enable_logs = os.getenv("ALERT_IDRAC_LOGS", "true").lower() in ("1", "true", "yes")

        messages = []
        for msg in raw:
            if "injoignable" in msg and not enable_offline:
                continue
            if "Santé hardware" in msg and not enable_health:
                continue
            if "Température" in msg and not enable_temp:
                continue
            if "PSU" in msg and not enable_psu:
                continue
            if "Ventilateur" in msg and not enable_fan:
                continue
            if ("Disque" in msg or "stockage" in msg.lower() or "Contrôleur" in msg) and not enable_disk:
                continue
            if "Logs critiques" in msg and not enable_logs:
                continue

            key = msg[:80]
            if self._can_send(f"idrac:{hash(key)}"):
                title = "iDRAC Hardware"
                if "injoignable" in msg:
                    title = "iDRAC offline"
                elif "Température" in msg:
                    title = "iDRAC Température"
                elif "PSU" in msg:
                    title = "iDRAC PSU"
                elif "Ventilateur" in msg:
                    title = "iDRAC Fan"
                elif "Disque" in msg or "stockage" in msg.lower() or "Contrôleur" in msg:
                    title = "iDRAC Stockage"
                elif "Logs critiques" in msg:
                    title = "iDRAC SEL"
                self._send(msg, title=title)
                messages.append(msg)
        return messages

    def check_and_alert(self, snapshot: Dict[str, Any]) -> List[str]:
        """Vérifie les seuils et envoie les alertes. Retourne la liste des messages envoyés."""
        messages = []

        for node in snapshot.get("nodes", []):
            name = node["node"]

            # CPU
            if node["cpu"] >= self.cpu_threshold:
                key = f"cpu:{name}"
                if self._can_send(key):
                    msg = (
                        f"🚨 **CPU élevé** sur le nœud `{name}`\n"
                        f"Utilisation : **{node['cpu']:.1f}%** (seuil {self.cpu_threshold}%)"
                    )
                    self._send(msg, title=f"Proxmox - CPU {name}")
                    messages.append(msg)

            # RAM
            if node["mem_pct"] >= self.ram_threshold:
                key = f"ram:{name}"
                if self._can_send(key):
                    msg = (
                        f"🚨 **RAM élevée** sur le nœud `{name}`\n"
                        f"Utilisation : **{node['mem_pct']:.1f}%** (seuil {self.ram_threshold}%)"
                    )
                    self._send(msg, title=f"Proxmox - RAM {name}")
                    messages.append(msg)

            # Disque
            if node["disk_pct"] >= self.disk_threshold:
                key = f"disk:{name}"
                if self._can_send(key):
                    msg = (
                        f"🚨 **Disque élevé** sur le nœud `{name}`\n"
                        f"Utilisation : **{node['disk_pct']:.1f}%** (seuil {self.disk_threshold}%)"
                    )
                    self._send(msg, title=f"Proxmox - Disque {name}")
                    messages.append(msg)

            # Nœud offline
            if node["status"] != "online":
                key = f"status:{name}"
                if self._can_send(key):
                    msg = f"🔴 **Nœud offline** : `{name}` (statut : {node['status']})"
                    self._send(msg, title=f"Proxmox - Nœud offline")
                    messages.append(msg)

            # Réseau — netin/netout sont en bytes/s → conversion en Mb/s
            netin_bps = node.get("netin_bps")
            netout_bps = node.get("netout_bps")
            if netin_bps is not None and self.net_in_threshold > 0:
                netin_mbps = (netin_bps * 8) / 1_000_000
                if netin_mbps >= self.net_in_threshold:
                    key = f"netin:{name}"
                    if self._can_send(key):
                        msg = (
                            f"🌐 **Débit download élevé** sur `{name}`\n"
                            f"Download : **{netin_mbps:.1f} Mb/s** "
                            f"(seuil {self.net_in_threshold} Mb/s)"
                        )
                        self._send(msg, title=f"Proxmox - Net ↓ {name}")
                        messages.append(msg)

            if netout_bps is not None and self.net_out_threshold > 0:
                netout_mbps = (netout_bps * 8) / 1_000_000
                if netout_mbps >= self.net_out_threshold:
                    key = f"netout:{name}"
                    if self._can_send(key):
                        msg = (
                            f"🌐 **Débit upload élevé** sur `{name}`\n"
                            f"Upload : **{netout_mbps:.1f} Mb/s** "
                            f"(seuil {self.net_out_threshold} Mb/s)"
                        )
                        self._send(msg, title=f"Proxmox - Net ↑ {name}")
                        messages.append(msg)

        return messages

    def _send(self, message: str, title: str = "Proxmox Alert"):
        if self.ntfy_enabled and self.ntfy_url:
            self._send_ntfy(message, title)
        if self.discord_enabled and self.discord_webhook:
            self._send_discord(message, title)
        if self.email_enabled:
            self._send_email(message, title)

    def _send_ntfy(self, message: str, title: str):
        headers = {
            "Title": title,
            "Priority": "high",
            "Tags": "warning,proxmox",
        }
        if self.ntfy_token:
            headers["Authorization"] = f"Bearer {self.ntfy_token}"
        try:
            requests.post(
                self.ntfy_url,
                data=message.encode("utf-8"),
                headers=headers,
                timeout=10,
            )
        except Exception as e:
            print(f"[Alert] Erreur ntfy : {e}")

    def _send_discord(self, message: str, title: str):
        # Convertir un peu le markdown
        content = message.replace("**", "**")
        payload = {
            "embeds": [
                {
                    "title": title,
                    "description": content,
                    "color": 15158332,  # rouge
                    "timestamp": datetime.utcnow().isoformat(),
                }
            ]
        }
        try:
            requests.post(self.discord_webhook, json=payload, timeout=10)
        except Exception as e:
            print(f"[Alert] Erreur Discord : {e}")

    def _send_email(self, message: str, title: str):
        if not all([self.smtp_host, self.smtp_user, self.smtp_password, self.email_to]):
            return
        try:
            msg = MIMEMultipart()
            msg["From"] = self.email_from or self.smtp_user
            msg["To"] = self.email_to
            msg["Subject"] = title
            msg.attach(MIMEText(message.replace("**", "").replace("`", ""), "plain"))

            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_user, self.smtp_password)
                server.send_message(msg)
        except Exception as e:
            print(f"[Alert] Erreur Email : {e}")
