#!/usr/bin/env python3
"""
Collecteur en arrière-plan : enregistre les métriques + envoie les alertes
À lancer en parallèle de Streamlit (ou en service systemd / cron)
"""

import os
import time
import signal
import sys
from datetime import datetime

from dotenv import load_dotenv

load_dotenv()

from core import ProxmoxClient, MetricsHistory
from alerts import AlertManager
from idrac import collect_all_idracs


def main():
    interval = int(os.getenv("COLLECT_INTERVAL", "30"))
    retention = int(os.getenv("HISTORY_RETENTION_DAYS", "7"))

    print(f"[{datetime.now()}] Démarrage du collecteur (intervalle = {interval}s)")

    try:
        client = ProxmoxClient()
        history = MetricsHistory()
        alerts = AlertManager()
    except Exception as e:
        print(f"Erreur d'initialisation : {e}")
        sys.exit(1)

    running = True

    def stop(sig, frame):
        nonlocal running
        print("\nArrêt du collecteur...")
        running = False

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)

    while running:
        try:
            snapshot = client.collect_all_metrics()
            history.save_snapshot(snapshot)
            sent = alerts.check_and_alert(snapshot)

            idrac_data = collect_all_idracs()
            if idrac_data:
                history.save_idrac_snapshot(idrac_data)
                sent += alerts.check_idrac_and_alert(idrac_data)

            if sent:
                print(f"[{datetime.now()}] {len(sent)} alerte(s) envoyée(s)")
            else:
                print(
                    f"[{datetime.now()}] Snapshot OK — "
                    f"{len(snapshot['nodes'])} nœud(s), {len(snapshot['guests'])} machine(s), "
                    f"{len(idrac_data)} iDRAC"
                )

            # Nettoyage périodique (toutes les ~1h)
            if int(time.time()) % 3600 < interval:
                history.cleanup(retention)

        except Exception as e:
            print(f"[{datetime.now()}] Erreur collecte : {e}")

        # Attente interruptible
        for _ in range(interval):
            if not running:
                break
            time.sleep(1)

    print("Collecteur arrêté proprement.")


if __name__ == "__main__":
    main()
