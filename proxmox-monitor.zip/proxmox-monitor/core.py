#!/usr/bin/env python3
"""
Core module - Connexion Proxmox + collecte de métriques + historique SQLite
"""

import os
import sqlite3
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

try:
    from proxmoxer import ProxmoxAPI
except ImportError:
    raise ImportError("proxmoxer manquant. pip install proxmoxer")


def format_bytes(size: Optional[float]) -> str:
    if size is None:
        return "N/A"
    size = float(size)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(size) < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def format_bps(bps: Optional[float]) -> str:
    """Formate un débit en bits/s ou bytes/s de façon lisible (affiche en bits/s)."""
    if bps is None:
        return "—"
    # On reçoit des bytes/s → conversion en bits/s pour affichage réseau classique
    bits = float(bps) * 8
    for unit in ["b/s", "Kb/s", "Mb/s", "Gb/s"]:
        if abs(bits) < 1000:
            return f"{bits:.1f} {unit}"
        bits /= 1000
    return f"{bits:.1f} Tb/s"


def format_uptime(seconds: Optional[int]) -> str:
    if not seconds:
        return "N/A"
    td = timedelta(seconds=int(seconds))
    days = td.days
    hours, remainder = divmod(td.seconds, 3600)
    minutes, _ = divmod(remainder, 60)
    if days > 0:
        return f"{days}j {hours}h {minutes}m"
    return f"{hours}h {minutes}m"


class ProxmoxClient:
    def __init__(
        self,
        host: Optional[str] = None,
        user: Optional[str] = None,
        token_name: Optional[str] = None,
        token_value: Optional[str] = None,
        password: Optional[str] = None,
        port: int = 8006,
        verify_ssl: bool = False,
    ):
        self.host = host or os.getenv("PROXMOX_HOST")
        self.port = port or int(os.getenv("PROXMOX_PORT", "8006"))
        self.user = user or os.getenv("PROXMOX_USER")
        self.token_name = token_name or os.getenv("PROXMOX_TOKEN_NAME")
        self.token_value = token_value or os.getenv("PROXMOX_TOKEN_VALUE")
        self.password = password or os.getenv("PROXMOX_PASSWORD")
        self.verify_ssl = (
            verify_ssl
            if verify_ssl is not None
            else os.getenv("PROXMOX_VERIFY_SSL", "false").lower() == "true"
        )

        if not self.host or not self.user:
            raise ValueError("PROXMOX_HOST et PROXMOX_USER sont obligatoires")

        if self.token_name and self.token_value:
            self.api = ProxmoxAPI(
                self.host,
                user=self.user,
                token_name=self.token_name,
                token_value=self.token_value,
                port=self.port,
                verify_ssl=self.verify_ssl,
            )
        elif self.password:
            self.api = ProxmoxAPI(
                self.host,
                user=self.user,
                password=self.password,
                port=self.port,
                verify_ssl=self.verify_ssl,
            )
        else:
            raise ValueError("Fournissez un token API ou un mot de passe")

    def get_version(self) -> Dict:
        return self.api.version.get()

    def get_nodes(self) -> List[Dict]:
        return self.api.nodes.get()

    def get_node_status(self, node: str) -> Dict:
        return self.api.nodes(node).status.get()

    def get_node_rrd(self, node: str, timeframe: str = "hour") -> List[Dict]:
        """Récupère les données RRD (contient netin/netout en bytes/s)."""
        try:
            return self.api.nodes(node).rrddata.get(timeframe=timeframe, cf="AVERAGE")
        except Exception:
            return []

    def get_node_net_rate(self, node: str) -> Dict[str, Optional[float]]:
        """Dernier débit réseau du nœud (bytes/s) via RRD."""
        samples = self.get_node_rrd(node, "hour")
        # On prend le dernier sample non nul
        for s in reversed(samples or []):
            netin = s.get("netin")
            netout = s.get("netout")
            if netin is not None or netout is not None:
                return {
                    "netin_bps": float(netin) if netin is not None else 0.0,
                    "netout_bps": float(netout) if netout is not None else 0.0,
                }
        return {"netin_bps": None, "netout_bps": None}

    def get_vms(self, node: str) -> List[Dict]:
        try:
            return self.api.nodes(node).qemu.get()
        except Exception:
            return []

    def get_containers(self, node: str) -> List[Dict]:
        try:
            return self.api.nodes(node).lxc.get()
        except Exception:
            return []

    def get_storage(self, node: str) -> List[Dict]:
        try:
            return self.api.nodes(node).storage.get()
        except Exception:
            return []

    def collect_all_metrics(self) -> Dict[str, Any]:
        """Collecte un snapshot complet des métriques (CPU, RAM, disque, réseau)."""
        nodes_raw = self.get_nodes()
        nodes = []
        guests = []
        storages = []

        for n in nodes_raw:
            node_name = n.get("node")
            cpu = (n.get("cpu") or 0) * 100
            mem_used = n.get("mem") or 0
            mem_max = n.get("maxmem") or 1
            mem_pct = (mem_used / mem_max * 100) if mem_max else 0
            disk_used = n.get("disk") or 0
            disk_max = n.get("maxdisk") or 1
            disk_pct = (disk_used / disk_max * 100) if disk_max else 0

            load = None
            try:
                st = self.get_node_status(node_name)
                loadavg = st.get("loadavg") or []
                if loadavg:
                    load = float(loadavg[0])
            except Exception:
                pass

            # Réseau nœud (bytes/s)
            net = self.get_node_net_rate(node_name)

            nodes.append(
                {
                    "node": node_name,
                    "status": n.get("status", "unknown"),
                    "cpu": round(cpu, 2),
                    "maxcpu": n.get("maxcpu") or 0,
                    "mem_used": mem_used,
                    "mem_max": mem_max,
                    "mem_pct": round(mem_pct, 2),
                    "disk_used": disk_used,
                    "disk_max": disk_max,
                    "disk_pct": round(disk_pct, 2),
                    "uptime": n.get("uptime") or 0,
                    "load": load,
                    "netin_bps": net.get("netin_bps"),
                    "netout_bps": net.get("netout_bps"),
                }
            )

            # VMs — netin/netout sont des compteurs cumulés (bytes)
            for vm in self.get_vms(node_name):
                guests.append(
                    {
                        "vmid": vm.get("vmid"),
                        "name": vm.get("name", "N/A"),
                        "type": "QEMU",
                        "node": node_name,
                        "status": vm.get("status", "unknown"),
                        "cpu": round((vm.get("cpu") or 0) * 100, 2),
                        "mem": vm.get("mem") or 0,
                        "maxmem": vm.get("maxmem") or 0,
                        "disk": vm.get("disk") or 0,
                        "maxdisk": vm.get("maxdisk") or 0,
                        "netin": vm.get("netin") or 0,      # total bytes
                        "netout": vm.get("netout") or 0,    # total bytes
                    }
                )

            # LXC
            for ct in self.get_containers(node_name):
                guests.append(
                    {
                        "vmid": ct.get("vmid"),
                        "name": ct.get("name", "N/A"),
                        "type": "LXC",
                        "node": node_name,
                        "status": ct.get("status", "unknown"),
                        "cpu": round((ct.get("cpu") or 0) * 100, 2),
                        "mem": ct.get("mem") or 0,
                        "maxmem": ct.get("maxmem") or 0,
                        "disk": ct.get("disk") or 0,
                        "maxdisk": ct.get("maxdisk") or 0,
                        "netin": ct.get("netin") or 0,
                        "netout": ct.get("netout") or 0,
                    }
                )

            # Storage
            for s in self.get_storage(node_name):
                used = s.get("used") or 0
                total = s.get("total") or 0
                pct = (used / total * 100) if total else 0
                storages.append(
                    {
                        "node": node_name,
                        "storage": s.get("storage", "N/A"),
                        "type": s.get("type", "N/A"),
                        "used": used,
                        "total": total,
                        "pct": round(pct, 2),
                        "active": bool(s.get("active")),
                    }
                )

        return {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "nodes": nodes,
            "guests": guests,
            "storages": storages,
        }


class MetricsHistory:
    """Stockage simple de l'historique dans SQLite."""

    def __init__(self, db_path: str = "proxmox_history.db"):
        self.db_path = Path(db_path)
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS node_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    node TEXT NOT NULL,
                    cpu REAL,
                    mem_pct REAL,
                    disk_pct REAL,
                    load REAL,
                    status TEXT,
                    netin_bps REAL,
                    netout_bps REAL
                )
                """
            )
            # Migration douce si colonnes réseau absentes
            try:
                conn.execute("ALTER TABLE node_metrics ADD COLUMN netin_bps REAL")
            except Exception:
                pass
            try:
                conn.execute("ALTER TABLE node_metrics ADD COLUMN netout_bps REAL")
            except Exception:
                pass

            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS guest_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    vmid INTEGER,
                    name TEXT,
                    type TEXT,
                    node TEXT,
                    status TEXT,
                    cpu REAL,
                    mem_pct REAL,
                    netin REAL,
                    netout REAL
                )
                """
            )
            try:
                conn.execute("ALTER TABLE guest_metrics ADD COLUMN netin REAL")
            except Exception:
                pass
            try:
                conn.execute("ALTER TABLE guest_metrics ADD COLUMN netout REAL")
            except Exception:
                pass

            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_node_ts ON node_metrics(node, timestamp)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_guest_ts ON guest_metrics(vmid, timestamp)"
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS idrac_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    name TEXT NOT NULL,
                    host TEXT,
                    health TEXT,
                    power_state TEXT,
                    power_watts REAL,
                    temp_inlet REAL,
                    temp_cpu_max REAL,
                    temp_max REAL,
                    reachable INTEGER
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_idrac_ts ON idrac_metrics(name, timestamp)"
            )
            conn.commit()

    def save_snapshot(self, snapshot: Dict[str, Any]):
        ts = snapshot["timestamp"]
        with sqlite3.connect(self.db_path) as conn:
            for n in snapshot["nodes"]:
                conn.execute(
                    """
                    INSERT INTO node_metrics
                    (timestamp, node, cpu, mem_pct, disk_pct, load, status, netin_bps, netout_bps)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ts,
                        n["node"],
                        n["cpu"],
                        n["mem_pct"],
                        n["disk_pct"],
                        n.get("load"),
                        n["status"],
                        n.get("netin_bps"),
                        n.get("netout_bps"),
                    ),
                )
            for g in snapshot["guests"]:
                mem_pct = (g["mem"] / g["maxmem"] * 100) if g.get("maxmem") else 0
                conn.execute(
                    """
                    INSERT INTO guest_metrics
                    (timestamp, vmid, name, type, node, status, cpu, mem_pct, netin, netout)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ts,
                        g["vmid"],
                        g["name"],
                        g["type"],
                        g["node"],
                        g["status"],
                        g["cpu"],
                        round(mem_pct, 2),
                        g.get("netin") or 0,
                        g.get("netout") or 0,
                    ),
                )
            conn.commit()

    def cleanup(self, retention_days: int = 7):
        cutoff = (datetime.utcnow() - timedelta(days=retention_days)).isoformat() + "Z"
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM node_metrics WHERE timestamp < ?", (cutoff,))
            conn.execute("DELETE FROM guest_metrics WHERE timestamp < ?", (cutoff,))
            try:
                conn.execute("DELETE FROM idrac_metrics WHERE timestamp < ?", (cutoff,))
            except Exception:
                pass
            conn.commit()

    def get_node_history(self, node: str, hours: int = 24) -> List[Dict]:
        since = (datetime.utcnow() - timedelta(hours=hours)).isoformat() + "Z"
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT timestamp, cpu, mem_pct, disk_pct, load, status, netin_bps, netout_bps
                FROM node_metrics
                WHERE node = ? AND timestamp >= ?
                ORDER BY timestamp ASC
                """,
                (node, since),
            ).fetchall()
            return [dict(r) for r in rows]


    def save_idrac_snapshot(self, snapshots: list):
        """Enregistre un snapshot iDRAC (températures + puissance)."""
        if not snapshots:
            return
        ts = __import__("datetime").datetime.utcnow().isoformat() + "Z"
        with sqlite3.connect(self.db_path) as conn:
            for s in snapshots:
                temps = s.get("temperatures") or []
                inlet = None
                cpu_temps = []
                all_temps = []
                for tmp in temps:
                    name = (tmp.get("name") or "").lower()
                    c = tmp.get("celsius")
                    if c is None:
                        continue
                    all_temps.append(c)
                    if "inlet" in name or "ambient" in name or "intake" in name:
                        inlet = c
                    if "cpu" in name or "processor" in name or "core" in name:
                        cpu_temps.append(c)
                temp_cpu_max = max(cpu_temps) if cpu_temps else None
                temp_max = max(all_temps) if all_temps else None
                conn.execute(
                    """
                    INSERT INTO idrac_metrics
                    (timestamp, name, host, health, power_state, power_watts,
                     temp_inlet, temp_cpu_max, temp_max, reachable)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ts,
                        s.get("name") or s.get("host") or "?",
                        s.get("host"),
                        s.get("health") or s.get("health_rollup"),
                        s.get("power_state"),
                        s.get("power_consumed_watts"),
                        inlet,
                        temp_cpu_max,
                        temp_max,
                        1 if s.get("reachable") else 0,
                    ),
                )
            conn.commit()

    def get_idrac_history(self, name: str, hours: int = 24) -> list:
        since = (__import__("datetime").datetime.utcnow() - __import__("datetime").timedelta(hours=hours)).isoformat() + "Z"
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT timestamp, health, power_state, power_watts,
                       temp_inlet, temp_cpu_max, temp_max, reachable
                FROM idrac_metrics
                WHERE name = ? AND timestamp >= ?
                ORDER BY timestamp ASC
                """,
                (name, since),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_available_idracs(self) -> list:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT DISTINCT name FROM idrac_metrics ORDER BY name"
            ).fetchall()
            return [r[0] for r in rows]

    def get_available_nodes(self) -> List[str]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT DISTINCT node FROM node_metrics ORDER BY node"
            ).fetchall()
            return [r[0] for r in rows]
