#!/usr/bin/env python3
"""
Client Redfish pour Dell iDRAC (PowerEdge)
Collecte santé hardware, températures, ventilateurs, PSU, puissance.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class IdracClient:
    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        verify_ssl: bool = False,
        timeout: int = 15,
        name: Optional[str] = None,
    ):
        self.host = host.rstrip("/")
        if not self.host.startswith("http"):
            self.host = f"https://{self.host}"
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.name = name or host
        self.session = requests.Session()
        self.session.auth = (username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({"Accept": "application/json"})

    def _get(self, path: str) -> Optional[Dict]:
        url = f"{self.host}{path}" if path.startswith("/") else f"{self.host}/{path}"
        try:
            r = self.session.get(url, timeout=self.timeout)
            if r.status_code == 200:
                return r.json()
            return None
        except Exception:
            return None


    def get_sel_logs(self, top: int = 50) -> List[Dict[str, Any]]:
        """Récupère les dernières entrées du System Event Log (SEL)."""
        paths = [
            "/redfish/v1/Managers/iDRAC.Embedded.1/LogServices/Sel/Entries",
            "/redfish/v1/Systems/System.Embedded.1/LogServices/Sel/Entries",
            "/redfish/v1/Managers/iDRAC.Embedded.1/Logs/Sel",
        ]
        entries: List[Dict[str, Any]] = []
        data = None
        for path in paths:
            data = self._get(path)
            if data:
                break
        if not data:
            return entries

        members = data.get("Members") or data.get("value") or []
        # Parfois pagination : Members@odata.count
        if not members and "@odata.id" in (data or {}):
            return entries

        for m in members[: top * 2]:  # marge si tri nécessaire
            # Member peut être un lien ou un objet complet
            if isinstance(m, dict) and m.get("Message") is None and m.get("@odata.id"):
                full = self._get(m["@odata.id"])
                if full:
                    m = full
            if not isinstance(m, dict):
                continue
            severity = (
                m.get("Severity")
                or m.get("EntryType")
                or (m.get("Oem") or {}).get("Dell", {}).get("Severity")
                or "Unknown"
            )
            entries.append(
                {
                    "id": m.get("Id") or m.get("MemberId"),
                    "created": m.get("Created") or m.get("EventTimestamp"),
                    "severity": severity,
                    "message": m.get("Message") or m.get("Description") or "",
                    "message_id": m.get("MessageId"),
                    "sensor": m.get("SensorType") or m.get("EntryCode"),
                }
            )

        # Trier du plus récent au plus ancien
        def _key(e):
            return e.get("created") or ""

        entries.sort(key=_key, reverse=True)
        return entries[:top]

    def get_lifecycle_logs(self, top: int = 30) -> List[Dict[str, Any]]:
        """Lifecycle Controller logs (Dell OEM)."""
        paths = [
            "/redfish/v1/Managers/iDRAC.Embedded.1/LogServices/Lclog/Entries",
            "/redfish/v1/Managers/iDRAC.Embedded.1/Logs/Lclog",
        ]
        entries: List[Dict[str, Any]] = []
        data = None
        for path in paths:
            data = self._get(path)
            if data:
                break
        if not data:
            return entries
        members = data.get("Members") or []
        for m in members[: top * 2]:
            if isinstance(m, dict) and m.get("Message") is None and m.get("@odata.id"):
                full = self._get(m["@odata.id"])
                if full:
                    m = full
            if not isinstance(m, dict):
                continue
            entries.append(
                {
                    "id": m.get("Id"),
                    "created": m.get("Created"),
                    "severity": m.get("Severity") or "Unknown",
                    "message": m.get("Message") or "",
                    "message_id": m.get("MessageId"),
                }
            )
        entries.sort(key=lambda e: e.get("created") or "", reverse=True)
        return entries[:top]

    def collect(self) -> Dict[str, Any]:
        """Collecte un snapshot hardware complet."""
        result: Dict[str, Any] = {
            "name": self.name,
            "host": self.host,
            "reachable": False,
            "model": None,
            "manufacturer": None,
            "serial": None,
            "power_state": None,
            "health": None,
            "health_rollup": None,
            "bios_version": None,
            "temperatures": [],
            "fans": [],
            "power_supplies": [],
            "power_consumed_watts": None,
            "storage_controllers": [],
            "drives": [],
            "processors": [],
            "memory_summary": None,
            "errors": [],
        }

        # System
        sys_data = self._get("/redfish/v1/Systems/System.Embedded.1")
        if not sys_data:
            # Essai chemin générique
            root = self._get("/redfish/v1/")
            if not root:
                result["errors"].append("Impossible de joindre l'iDRAC (réseau / auth)")
                return result
            systems = self._get("/redfish/v1/Systems")
            members = (systems or {}).get("Members") or []
            if members:
                sys_path = members[0].get("@odata.id", "")
                sys_data = self._get(sys_path)

        if not sys_data:
            result["errors"].append("Endpoint Systems inaccessible")
            return result

        result["reachable"] = True
        result["model"] = sys_data.get("Model")
        result["manufacturer"] = sys_data.get("Manufacturer")
        result["serial"] = sys_data.get("SerialNumber")
        result["power_state"] = sys_data.get("PowerState")
        result["bios_version"] = sys_data.get("BiosVersion")

        status = sys_data.get("Status") or {}
        result["health"] = status.get("Health")
        result["health_rollup"] = status.get("HealthRollup")

        # Processors summary
        proc_count = (sys_data.get("ProcessorSummary") or {}).get("Count")
        proc_model = (sys_data.get("ProcessorSummary") or {}).get("Model")
        if proc_count:
            result["processors"] = [{"count": proc_count, "model": proc_model}]

        mem = sys_data.get("MemorySummary") or {}
        if mem:
            result["memory_summary"] = {
                "total_gib": mem.get("TotalSystemMemoryGiB"),
                "health": (mem.get("Status") or {}).get("Health"),
            }

        # Chassis → Thermal + Power
        chassis = self._get("/redfish/v1/Chassis/System.Embedded.1")
        if not chassis:
            ch_col = self._get("/redfish/v1/Chassis")
            members = (ch_col or {}).get("Members") or []
            if members:
                chassis = self._get(members[0].get("@odata.id", ""))

        if chassis:
            # Thermal
            thermal_link = (chassis.get("Thermal") or {}).get("@odata.id")
            if thermal_link:
                thermal = self._get(thermal_link)
            else:
                thermal = self._get("/redfish/v1/Chassis/System.Embedded.1/Thermal")

            if thermal:
                for t in thermal.get("Temperatures") or []:
                    reading = t.get("ReadingCelsius")
                    if reading is None:
                        continue
                    result["temperatures"].append(
                        {
                            "name": t.get("Name") or t.get("PhysicalContext") or "Temp",
                            "celsius": reading,
                            "status": (t.get("Status") or {}).get("Health"),
                            "upper_critical": t.get("UpperThresholdCritical"),
                            "upper_caution": t.get("UpperThresholdNonCritical"),
                        }
                    )
                for f in thermal.get("Fans") or []:
                    result["fans"].append(
                        {
                            "name": f.get("Name") or f.get("FanName") or "Fan",
                            "rpm": f.get("Reading") or f.get("ReadingRPM"),
                            "status": (f.get("Status") or {}).get("Health"),
                            "state": (f.get("Status") or {}).get("State"),
                        }
                    )

            # Power
            power_link = (chassis.get("Power") or {}).get("@odata.id")
            if power_link:
                power = self._get(power_link)
            else:
                power = self._get("/redfish/v1/Chassis/System.Embedded.1/Power")

            if power:
                result["power_consumed_watts"] = power.get("PowerControl", [{}])[0].get(
                    "PowerConsumedWatts"
                ) if power.get("PowerControl") else power.get("PowerConsumedWatts")
                # Sometimes nested differently
                if result["power_consumed_watts"] is None:
                    pcs = power.get("PowerControl") or []
                    if pcs:
                        result["power_consumed_watts"] = pcs[0].get("PowerConsumedWatts")

                for psu in power.get("PowerSupplies") or []:
                    result["power_supplies"].append(
                        {
                            "name": psu.get("Name") or psu.get("MemberId") or "PSU",
                            "status": (psu.get("Status") or {}).get("Health"),
                            "state": (psu.get("Status") or {}).get("State"),
                            "capacity_watts": psu.get("PowerCapacityWatts"),
                            "input_voltage": psu.get("LineInputVoltage"),
                            "model": psu.get("Model"),
                        }
                    )

        # Storage (best effort)
        storage = self._get("/redfish/v1/Systems/System.Embedded.1/Storage")
        if storage:
            for m in storage.get("Members") or []:
                ctrl_path = m.get("@odata.id")
                if not ctrl_path:
                    continue
                ctrl = self._get(ctrl_path)
                if not ctrl:
                    continue
                result["storage_controllers"].append(
                    {
                        "name": ctrl.get("Name") or ctrl.get("Id"),
                        "status": (ctrl.get("Status") or {}).get("Health"),
                        "model": (ctrl.get("StorageControllers") or [{}])[0].get("Model")
                        if ctrl.get("StorageControllers")
                        else None,
                    }
                )
                for d in ctrl.get("Drives") or []:
                    dpath = d.get("@odata.id")
                    if not dpath:
                        continue
                    drive = self._get(dpath)
                    if not drive:
                        continue
                    result["drives"].append(
                        {
                            "name": drive.get("Name") or drive.get("Id"),
                            "status": (drive.get("Status") or {}).get("Health"),
                            "capacity_bytes": drive.get("CapacityBytes"),
                            "media_type": drive.get("MediaType"),
                            "failure_predicted": drive.get("FailurePredicted"),
                        }
                    )

        # Derniers logs critiques (aperçu)
        try:
            sel = self.get_sel_logs(top=20)
            result["sel_logs"] = sel
            result["sel_critical_count"] = sum(
                1
                for e in sel
                if str(e.get("severity") or "").lower()
                in ("critical", "error", "fatal", "emergency")
            )
        except Exception as e:
            result["errors"].append(f"SEL: {e}")
            result["sel_logs"] = []
            result["sel_critical_count"] = 0

        return result


def load_idrac_hosts_from_env() -> List[Dict[str, str]]:
    """
    Format .env :
      IDRAC_HOSTS=192.168.1.101,192.168.1.102,192.168.1.103
      IDRAC_USER=root
      IDRAC_PASSWORD=calvin
    Ou par serveur :
      IDRAC_1_HOST=...
      IDRAC_1_NAME=pve1-hw
      IDRAC_1_USER=root
      IDRAC_1_PASSWORD=...
    """
    hosts: List[Dict[str, str]] = []

    # Mode simple : liste d'IPs + user/pass communs
    common_user = os.getenv("IDRAC_USER", "root")
    common_pass = os.getenv("IDRAC_PASSWORD", "")
    hosts_str = os.getenv("IDRAC_HOSTS", "").strip()
    if hosts_str and common_pass:
        for i, h in enumerate(hosts_str.split(",")):
            h = h.strip()
            if h:
                hosts.append(
                    {
                        "host": h,
                        "username": common_user,
                        "password": common_pass,
                        "name": h,
                    }
                )

    # Mode détaillé IDRAC_N_*
    for i in range(1, 20):
        h = os.getenv(f"IDRAC_{i}_HOST")
        if not h:
            continue
        hosts.append(
            {
                "host": h,
                "username": os.getenv(f"IDRAC_{i}_USER", common_user),
                "password": os.getenv(f"IDRAC_{i}_PASSWORD", common_pass),
                "name": os.getenv(f"IDRAC_{i}_NAME", h),
            }
        )

    return hosts


def collect_all_idracs(max_workers: int = 4) -> List[Dict[str, Any]]:
    configs = load_idrac_hosts_from_env()
    if not configs:
        return []

    verify = os.getenv("IDRAC_VERIFY_SSL", "false").lower() == "true"
    results: List[Dict[str, Any]] = []

    def _one(cfg: Dict) -> Dict:
        client = IdracClient(
            host=cfg["host"],
            username=cfg["username"],
            password=cfg["password"],
            verify_ssl=verify,
            name=cfg.get("name"),
        )
        return client.collect()

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs = {ex.submit(_one, c): c for c in configs}
        for fut in as_completed(futs):
            try:
                results.append(fut.result())
            except Exception as e:
                cfg = futs[fut]
                results.append(
                    {
                        "name": cfg.get("name", cfg["host"]),
                        "host": cfg["host"],
                        "reachable": False,
                        "errors": [str(e)],
                        "temperatures": [],
                        "fans": [],
                        "power_supplies": [],
                        "drives": [],
                        "storage_controllers": [],
                    }
                )

    results.sort(key=lambda x: x.get("name") or "")
    return results


def check_idrac_alerts(
    snapshots: List[Dict[str, Any]],
    temp_threshold: float = 0,
) -> List[str]:
    """
    Retourne une liste de messages d'alerte hardware.
    temp_threshold en °C (0 = désactivé, utilise les seuils iDRAC si absents).
    """
    messages: List[str] = []

    for s in snapshots:
        name = s.get("name") or s.get("host") or "?"

        if not s.get("reachable"):
            messages.append(f"🔴 **iDRAC injoignable** : `{name}`")
            continue

        health = (s.get("health") or s.get("health_rollup") or "OK") or "OK"
        if str(health).upper() not in ("OK", "OKAY"):
            messages.append(
                f"⚠️ **Santé hardware** `{name}` : **{health}** "
                f"({s.get('model') or 'PowerEdge'})"
            )

        # PSU
        for psu in s.get("power_supplies") or []:
            st = (psu.get("status") or "OK") or "OK"
            if str(st).upper() not in ("OK", "OKAY"):
                messages.append(
                    f"🔌 **PSU** `{name}` / {psu.get('name')} : **{st}**"
                )

        # Fans
        for fan in s.get("fans") or []:
            st = (fan.get("status") or "OK") or "OK"
            if str(st).upper() not in ("OK", "OKAY"):
                messages.append(
                    f"🌀 **Ventilateur** `{name}` / {fan.get('name')} : **{st}**"
                )

        # Températures
        for t in s.get("temperatures") or []:
            st = (t.get("status") or "OK") or "OK"
            celsius = t.get("celsius")
            upper = t.get("upper_critical") or t.get("upper_caution")
            over = False
            if temp_threshold > 0 and celsius is not None and celsius >= temp_threshold:
                over = True
            if upper is not None and celsius is not None and celsius >= upper:
                over = True
            if str(st).upper() not in ("OK", "OKAY") or over:
                messages.append(
                    f"🌡️ **Température** `{name}` / {t.get('name')} : "
                    f"**{celsius}°C** (status {st})"
                )

        # Disques
        for d in s.get("drives") or []:
            st = (d.get("status") or "OK") or "OK"
            if str(st).upper() not in ("OK", "OKAY") or d.get("failure_predicted"):
                messages.append(
                    f"💾 **Disque** `{name}` / {d.get('name')} : **{st}**"
                    + (" (failure predicted)" if d.get("failure_predicted") else "")
                )

        # Storage controllers
        for c in s.get("storage_controllers") or []:
            st = (c.get("status") or "OK") or "OK"
            if str(st).upper() not in ("OK", "OKAY"):
                messages.append(
                    f"🗄️ **Contrôleur stockage** `{name}` / {c.get('name')} : **{st}**"
                )

        # Logs SEL critiques récents
        crit = s.get("sel_critical_count") or 0
        if crit > 0:
            sample = []
            for e in (s.get("sel_logs") or [])[:5]:
                sev = str(e.get("severity") or "").lower()
                if sev in ("critical", "error", "fatal", "emergency"):
                    sample.append(e.get("message") or e.get("message_id") or "?")
            detail = " | ".join(sample[:2])
            messages.append(
                f"📋 **Logs critiques SEL** sur `{name}` : {crit} entrée(s) récente(s)"
                + (f" — {detail}" if detail else "")
            )

    return messages
