#!/usr/bin/env python3
"""
Proxmox Monitor - CLI de supervision Proxmox VE
"""

import os
import sys
import time
import argparse
from datetime import datetime

from dotenv import load_dotenv
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box
from rich.align import Align

load_dotenv()

from core import ProxmoxClient, MetricsHistory, format_bytes, format_uptime, format_bps
from alerts import AlertManager

console = Console()


def percent_color(value: float) -> str:
    if value is None:
        return "white"
    if value < 50:
        return "green"
    if value < 80:
        return "yellow"
    return "red"


class CLIMonitor:
    def __init__(self, client: ProxmoxClient, history: MetricsHistory, alerts: AlertManager):
        self.client = client
        self.history = history
        self.alerts = alerts

    def create_header(self) -> Panel:
        try:
            version = self.client.get_version()
            ver_str = f"Proxmox VE {version.get('version', '?')} (release {version.get('release', '?')})"
        except Exception:
            ver_str = "Proxmox VE"

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        text = Text()
        text.append("🔍 Proxmox Monitor\n", style="bold white")
        text.append(f"{ver_str}\n", style="cyan")
        text.append(f"Host : {self.client.host}:{self.client.port}  |  {now}", style="dim")
        return Panel(Align.center(text), style="bold blue", box=box.DOUBLE)

    def create_cluster_summary(self, nodes: list, guests: list) -> Panel:
        online = sum(1 for n in nodes if n.get("status") == "online")
        avg_cpu = sum(n.get("cpu", 0) for n in nodes) / len(nodes) if nodes else 0
        total_mem_used = sum(n.get("mem_used", 0) for n in nodes)
        total_mem_max = sum(n.get("mem_max", 1) for n in nodes)
        mem_pct = (total_mem_used / total_mem_max * 100) if total_mem_max else 0
        running = sum(1 for g in guests if g.get("status") == "running")
        total_cores = sum(n.get("maxcpu") or 0 for n in nodes)

        text = Text()
        text.append("🌐 Cluster  ", style="bold cyan")
        text.append(f"{online}/{len(nodes)} nœuds  •  ")
        text.append(f"CPU moy. {avg_cpu:.0f}%  •  ")
        text.append(f"RAM {mem_pct:.0f}%  •  ")
        text.append(f"{running}/{len(guests)} machines running  •  ")
        text.append(f"{total_cores} cœurs")
        return Panel(text, style="bold blue", box=box.ROUNDED)

    def create_nodes_table(self, nodes: list) -> Table:
        table = Table(
            title="🖥️  Nœuds Proxmox",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title_style="bold magenta",
        )
        table.add_column("Nœud", style="bold")
        table.add_column("Statut", justify="center")
        table.add_column("CPU", justify="right")
        table.add_column("RAM", justify="right")
        table.add_column("Disque", justify="right")
        table.add_column("Net ↓", justify="right")
        table.add_column("Net ↑", justify="right")
        table.add_column("Uptime", justify="right")

        for node in nodes:
            status = node.get("status", "unknown")
            status_style = "green" if status == "online" else "red"
            cpu = node.get("cpu", 0)
            mem_pct = node.get("mem_pct", 0)
            disk_pct = node.get("disk_pct", 0)

            table.add_row(
                node["node"],
                Text(status.upper(), style=status_style),
                Text(f"{cpu:.1f}%", style=percent_color(cpu)),
                Text(
                    f"{format_bytes(node['mem_used'])} / {format_bytes(node['mem_max'])} ({mem_pct:.0f}%)",
                    style=percent_color(mem_pct),
                ),
                Text(
                    f"{format_bytes(node['disk_used'])} / {format_bytes(node['disk_max'])} ({disk_pct:.0f}%)",
                    style=percent_color(disk_pct),
                ),
                format_bps(node.get("netin_bps")),
                format_bps(node.get("netout_bps")),
                format_uptime(node.get("uptime")),
            )
        return table

    def create_guests_table(self, guests: list) -> Table:
        table = Table(
            title="📦 Machines virtuelles & Conteneurs",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title_style="bold magenta",
        )
        table.add_column("ID", style="bold", justify="right")
        table.add_column("Nom")
        table.add_column("Type", justify="center")
        table.add_column("Nœud")
        table.add_column("Statut", justify="center")
        table.add_column("CPU", justify="right")
        table.add_column("RAM", justify="right")
        table.add_column("Net ↓", justify="right")
        table.add_column("Net ↑", justify="right")

        for g in sorted(guests, key=lambda x: x.get("vmid") or 0):
            status = g.get("status", "unknown")
            status_style = (
                "green" if status == "running" else "red" if status == "stopped" else "yellow"
            )
            mem_pct = (g["mem"] / g["maxmem"] * 100) if g.get("maxmem") else 0

            table.add_row(
                str(g["vmid"]),
                g["name"],
                g["type"],
                g["node"],
                Text(status.upper(), style=status_style),
                Text(f"{g['cpu']:.1f}%", style=percent_color(g["cpu"])),
                Text(
                    f"{format_bytes(g['mem'])} ({mem_pct:.0f}%)",
                    style=percent_color(mem_pct),
                ),
                format_bytes(g.get("netin") or 0),
                format_bytes(g.get("netout") or 0),
            )

        if not guests:
            table.add_row("—", "Aucune machine trouvée", "—", "—", "—", "—", "—", "—", "—")
        return table

    def create_storage_table(self, storages: list) -> Table:
        table = Table(
            title="💾 Stockage",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title_style="bold magenta",
        )
        table.add_column("Nœud")
        table.add_column("Stockage", style="bold")
        table.add_column("Type")
        table.add_column("Utilisé", justify="right")
        table.add_column("Total", justify="right")
        table.add_column("%", justify="right")
        table.add_column("Actif", justify="center")

        for s in storages:
            pct = s.get("pct", 0)
            table.add_row(
                s["node"],
                s["storage"],
                s["type"],
                format_bytes(s["used"]),
                format_bytes(s["total"]),
                Text(f"{pct:.0f}%", style=percent_color(pct)),
                Text("✓", style="green") if s.get("active") else Text("✗", style="red"),
            )
        return table

    def render(self):
        snapshot = self.client.collect_all_metrics()
        self.history.save_snapshot(snapshot)
        sent = self.alerts.check_and_alert(snapshot)

        console.clear()
        console.print(self.create_header())
        console.print()
        console.print(self.create_cluster_summary(snapshot["nodes"], snapshot["guests"]))
        console.print()
        console.print(self.create_nodes_table(snapshot["nodes"]))
        console.print()
        console.print(self.create_guests_table(snapshot["guests"]))
        console.print()
        console.print(self.create_storage_table(snapshot["storages"]))

        if sent:
            console.print()
            for msg in sent:
                console.print(f"[bold red]ALERTE :[/bold red] {msg}")

    def run_once(self):
        self.render()

    def run_live(self, interval: int = 5):
        console.print("[bold green]Monitoring CLI en temps réel...[/bold green]")
        console.print(f"[dim]Rafraîchissement toutes les {interval}s — Ctrl+C pour arrêter[/dim]\n")
        try:
            while True:
                self.render()
                time.sleep(interval)
        except KeyboardInterrupt:
            console.print("\n[bold yellow]Monitoring arrêté.[/bold yellow]")


def main():
    parser = argparse.ArgumentParser(description="CLI de supervision Proxmox VE")
    parser.add_argument("--live", action="store_true", help="Mode monitoring continu")
    parser.add_argument(
        "--interval",
        type=int,
        default=int(os.getenv("REFRESH_INTERVAL", "5")),
        help="Intervalle de rafraîchissement (secondes)",
    )
    args = parser.parse_args()

    try:
        client = ProxmoxClient()
        history = MetricsHistory()
        alerts = AlertManager()
    except Exception as e:
        console.print(f"[bold red]Erreur :[/bold red] {e}")
        sys.exit(1)

    monitor = CLIMonitor(client, history, alerts)

    if args.live:
        monitor.run_live(interval=args.interval)
    else:
        monitor.run_once()


if __name__ == "__main__":
    main()
