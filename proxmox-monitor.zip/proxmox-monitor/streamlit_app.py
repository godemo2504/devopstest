#!/usr/bin/env python3
"""
Interface web Streamlit pour la supervision Proxmox
"""

import os
import time
from datetime import datetime

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dotenv import load_dotenv

load_dotenv()

from core import ProxmoxClient, MetricsHistory, format_bytes, format_uptime, format_bps
from alerts import AlertManager
from idrac import collect_all_idracs


st.set_page_config(
    page_title="Proxmox Monitor",
    page_icon="🖥️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
<style>
    .stMetric {
        background-color: #1e293b;
        padding: 10px 15px;
        border-radius: 8px;
    }
</style>
""",
    unsafe_allow_html=True,
)


@st.cache_resource
def get_client():
    try:
        return ProxmoxClient()
    except Exception as e:
        st.error(f"Erreur de connexion Proxmox : {e}")
        st.stop()


@st.cache_resource
def get_history():
    return MetricsHistory()


@st.cache_resource
def get_alert_manager():
    return AlertManager()


def compute_cluster_stats(nodes, guests):
    """Calcule les statistiques globales du cluster."""
    online = sum(1 for n in nodes if n["status"] == "online")
    total_cpu_cores = sum(n.get("maxcpu") or 0 for n in nodes)
    avg_cpu = sum(n["cpu"] for n in nodes) / len(nodes) if nodes else 0

    total_mem_used = sum(n["mem_used"] for n in nodes)
    total_mem_max = sum(n["mem_max"] for n in nodes)
    mem_pct = (total_mem_used / total_mem_max * 100) if total_mem_max else 0

    total_disk_used = sum(n["disk_used"] for n in nodes)
    total_disk_max = sum(n["disk_max"] for n in nodes)
    disk_pct = (total_disk_used / total_disk_max * 100) if total_disk_max else 0

    # Réseau cluster (somme des débits nœuds)
    total_netin = sum(n.get("netin_bps") or 0 for n in nodes)
    total_netout = sum(n.get("netout_bps") or 0 for n in nodes)

    running = sum(1 for g in guests if g["status"] == "running")
    stopped = sum(1 for g in guests if g["status"] == "stopped")
    qemu = sum(1 for g in guests if g["type"] == "QEMU")
    lxc = sum(1 for g in guests if g["type"] == "LXC")

    per_node = {}
    for n in nodes:
        name = n["node"]
        per_node[name] = {
            "cpu": n["cpu"],
            "mem_pct": n["mem_pct"],
            "disk_pct": n["disk_pct"],
            "mem_used": n["mem_used"],
            "mem_max": n["mem_max"],
            "status": n["status"],
            "maxcpu": n.get("maxcpu") or 0,
            "netin_bps": n.get("netin_bps"),
            "netout_bps": n.get("netout_bps"),
            "vms_running": sum(
                1 for g in guests if g["node"] == name and g["status"] == "running"
            ),
            "vms_total": sum(1 for g in guests if g["node"] == name),
        }

    return {
        "nodes_total": len(nodes),
        "nodes_online": online,
        "total_cpu_cores": total_cpu_cores,
        "avg_cpu": round(avg_cpu, 1),
        "total_mem_used": total_mem_used,
        "total_mem_max": total_mem_max,
        "mem_pct": round(mem_pct, 1),
        "total_disk_used": total_disk_used,
        "total_disk_max": total_disk_max,
        "disk_pct": round(disk_pct, 1),
        "total_netin_bps": total_netin,
        "total_netout_bps": total_netout,
        "guests_total": len(guests),
        "running": running,
        "stopped": stopped,
        "qemu": qemu,
        "lxc": lxc,
        "per_node": per_node,
    }


def main():
    client = get_client()
    history = get_history()
    alerts = get_alert_manager()

    # Sidebar
    with st.sidebar:
        st.title("🖥️ Proxmox Monitor")
        st.caption("Supervision cluster")

        try:
            version = client.get_version()
            st.info(
                f"**Proxmox VE** {version.get('version', '?')}\n\n"
                f"Release : {version.get('release', '?')}"
            )
        except Exception:
            st.warning("Impossible de récupérer la version")

        st.divider()

        auto_refresh = st.toggle("🔄 Rafraîchissement auto", value=True)
        refresh_interval = st.slider("Intervalle (secondes)", 10, 120, 30)

        st.divider()
        st.subheader("Historique")
        history_hours = st.selectbox(
            "Période des graphiques",
            options=[6, 12, 24, 48, 72],
            index=2,
            format_func=lambda x: f"{x} heures",
        )

        st.divider()
        if st.button("🧹 Nettoyer l'historique ancien", use_container_width=True):
            days = int(os.getenv("HISTORY_RETENTION_DAYS", "7"))
            history.cleanup(days)
            st.success(f"Historique > {days} jours supprimé")

        st.divider()
        st.caption(f"Host : `{client.host}:{client.port}`")
        st.caption(f"Dernière MAJ : {datetime.now().strftime('%H:%M:%S')}")

    # Collecte
    try:
        snapshot = client.collect_all_metrics()
        history.save_snapshot(snapshot)
        sent_alerts = alerts.check_and_alert(snapshot)
    except Exception as e:
        st.error(f"Erreur lors de la collecte : {e}")
        st.stop()

    # Hardware iDRAC (optionnel)
    idrac_data = []
    try:
        idrac_data = collect_all_idracs()
        if idrac_data:
            history.save_idrac_snapshot(idrac_data)
            sent_alerts.extend(alerts.check_idrac_and_alert(idrac_data))
    except Exception as e:
        st.sidebar.warning(f"iDRAC : {e}")

    nodes = snapshot["nodes"]
    guests = snapshot["guests"]
    cluster = compute_cluster_stats(nodes, guests)

    # === En-tête global ===
    st.title("Supervision Proxmox — Cluster")

    # Ligne de métriques principales
    c1, c2, c3, c4, c5, c6, c7 = st.columns(7)
    c1.metric("Nœuds", f"{cluster['nodes_online']}/{cluster['nodes_total']}")
    c2.metric("CPU moyen", f"{cluster['avg_cpu']}%")
    c3.metric("RAM cluster", f"{cluster['mem_pct']}%")
    c4.metric("Disque", f"{cluster['disk_pct']}%")
    c5.metric("Net ↓", format_bps(cluster.get("total_netin_bps")))
    c6.metric("Net ↑", format_bps(cluster.get("total_netout_bps")))
    c7.metric("Machines", f"{cluster['running']}/{cluster['guests_total']}")

    if sent_alerts:
        with st.expander(f"🚨 {len(sent_alerts)} alerte(s) envoyée(s)", expanded=True):
            for a in sent_alerts:
                st.warning(a)

    st.divider()

    # === Onglets ===
    tab0, tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
        ["🌐 Vue Cluster", "📊 Nœuds", "📦 Machines", "🌐 Réseau", "💾 Stockage", "🖥️ Hardware iDRAC", "📈 Historique"]
    )

    # ===================== VUE CLUSTER =====================
    with tab0:
        st.subheader("Vue d'ensemble du cluster")

        # Ressources globales
        col_left, col_right = st.columns(2)

        with col_left:
            st.markdown("#### Ressources globales")
            st.write(
                f"**CPU** : {cluster['total_cpu_cores']} cœurs — utilisation moyenne **{cluster['avg_cpu']}%**"
            )
            st.progress(min(cluster["avg_cpu"] / 100, 1.0))

            st.write(
                f"**RAM** : {format_bytes(cluster['total_mem_used'])} / {format_bytes(cluster['total_mem_max'])} "
                f"(**{cluster['mem_pct']}%**)"
            )
            st.progress(min(cluster["mem_pct"] / 100, 1.0))

            st.write(
                f"**Disque** : {format_bytes(cluster['total_disk_used'])} / {format_bytes(cluster['total_disk_max'])} "
                f"(**{cluster['disk_pct']}%**)"
            )
            st.progress(min(cluster["disk_pct"] / 100, 1.0))

            st.markdown("#### Machines")
            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Total", cluster["guests_total"])
            m2.metric("Running", cluster["running"])
            m3.metric("QEMU", cluster["qemu"])
            m4.metric("LXC", cluster["lxc"])

        with col_right:
            st.markdown("#### Répartition des machines par nœud")
            if cluster["per_node"]:
                df_dist = pd.DataFrame(
                    [
                        {
                            "Nœud": name,
                            "Running": info["vms_running"],
                            "Total": info["vms_total"],
                            "Arrêtées": info["vms_total"] - info["vms_running"],
                        }
                        for name, info in cluster["per_node"].items()
                    ]
                )
                fig = px.bar(
                    df_dist,
                    x="Nœud",
                    y=["Running", "Arrêtées"],
                    title="VMs / Conteneurs par nœud",
                    barmode="stack",
                    color_discrete_map={"Running": "#22c55e", "Arrêtées": "#64748b"},
                )
                fig.update_layout(template="plotly_dark", height=320, legend_title=None)
                st.plotly_chart(fig, use_container_width=True)

        st.divider()
        st.markdown("#### Charge par nœud")

        # Graphiques comparatifs
        if cluster["per_node"]:
            df_nodes = pd.DataFrame(
                [
                    {
                        "Nœud": name,
                        "CPU %": info["cpu"],
                        "RAM %": info["mem_pct"],
                        "Disque %": info["disk_pct"],
                        "Statut": info["status"],
                    }
                    for name, info in cluster["per_node"].items()
                ]
            )

            fig2 = go.Figure()
            fig2.add_trace(
                go.Bar(name="CPU %", x=df_nodes["Nœud"], y=df_nodes["CPU %"], marker_color="#3b82f6")
            )
            fig2.add_trace(
                go.Bar(name="RAM %", x=df_nodes["Nœud"], y=df_nodes["RAM %"], marker_color="#10b981")
            )
            fig2.add_trace(
                go.Bar(
                    name="Disque %",
                    x=df_nodes["Nœud"],
                    y=df_nodes["Disque %"],
                    marker_color="#f59e0b",
                )
            )
            fig2.update_layout(
                barmode="group",
                template="plotly_dark",
                height=380,
                yaxis=dict(range=[0, 100], title="Utilisation (%)"),
                legend=dict(orientation="h", y=1.12),
                title="Comparaison des ressources par nœud",
            )
            st.plotly_chart(fig2, use_container_width=True)

            # Tableau récapitulatif
            st.markdown("#### Détail par nœud")
            detail_rows = []
            for name, info in cluster["per_node"].items():
                detail_rows.append(
                    {
                        "Nœud": name,
                        "Statut": "🟢 online" if info["status"] == "online" else "🔴 " + info["status"],
                        "Cœurs": info["maxcpu"],
                        "CPU %": f"{info['cpu']:.1f}",
                        "RAM %": f"{info['mem_pct']:.1f}",
                        "Disque %": f"{info['disk_pct']:.1f}",
                        "Net ↓": format_bps(info.get("netin_bps")),
                        "Net ↑": format_bps(info.get("netout_bps")),
                        "VMs Running": info["vms_running"],
                        "VMs Total": info["vms_total"],
                    }
                )
            st.dataframe(pd.DataFrame(detail_rows), use_container_width=True, hide_index=True)

    # ===================== NŒUDS =====================
    with tab1:
        st.subheader("État détaillé des nœuds")
        for node in nodes:
            with st.container():
                c1, c2, c3, c4, c5, c6 = st.columns([2, 1, 1, 1, 1, 1])
                status_icon = "🟢" if node["status"] == "online" else "🔴"
                c1.markdown(f"### {status_icon} `{node['node']}`")
                c2.metric("CPU", f"{node['cpu']:.1f}%")
                c3.metric("RAM", f"{node['mem_pct']:.1f}%")
                c4.metric("Disque", f"{node['disk_pct']:.1f}%")
                c5.metric("Net ↓", format_bps(node.get("netin_bps")))
                c6.metric("Net ↑", format_bps(node.get("netout_bps")))

                p1, p2, p3 = st.columns(3)
                p1.progress(min(node["cpu"] / 100, 1.0), text=f"CPU {node['cpu']:.1f}%")
                p2.progress(min(node["mem_pct"] / 100, 1.0), text=f"RAM {node['mem_pct']:.1f}%")
                p3.progress(min(node["disk_pct"] / 100, 1.0), text=f"Disque {node['disk_pct']:.1f}%")

                st.caption(
                    f"Uptime : {format_uptime(node['uptime'])}  •  "
                    f"RAM : {format_bytes(node['mem_used'])} / {format_bytes(node['mem_max'])}  •  "
                    f"Disque : {format_bytes(node['disk_used'])} / {format_bytes(node['disk_max'])}"
                    + (f"  •  Load : {node['load']:.2f}" if node.get("load") else "")
                    + (f"  •  Cœurs : {node.get('maxcpu', '?')}" if node.get("maxcpu") else "")
                )
                st.divider()

    # ===================== MACHINES =====================
    with tab2:
        st.subheader("Machines virtuelles & Conteneurs")

        if not guests:
            st.info("Aucune machine trouvée")
        else:
            df = pd.DataFrame(guests)
            df["mem_pct"] = df.apply(
                lambda r: round(r["mem"] / r["maxmem"] * 100, 1) if r["maxmem"] else 0,
                axis=1,
            )
            df["disk_pct"] = df.apply(
                lambda r: round(r["disk"] / r["maxdisk"] * 100, 1) if r.get("maxdisk") else 0,
                axis=1,
            )

            f1, f2, f3 = st.columns(3)
            type_filter = f1.multiselect("Type", options=["QEMU", "LXC"], default=["QEMU", "LXC"])
            status_filter = f2.multiselect(
                "Statut",
                options=sorted(df["status"].unique()),
                default=sorted(df["status"].unique()),
            )
            node_filter = f3.multiselect(
                "Nœud",
                options=sorted(df["node"].unique()),
                default=sorted(df["node"].unique()),
            )

            filtered = df[
                (df["type"].isin(type_filter))
                & (df["status"].isin(status_filter))
                & (df["node"].isin(node_filter))
            ]

            # Trafic cumulé (depuis boot de la VM)
            filtered = filtered.copy()
            filtered["netin_h"] = filtered["netin"].apply(lambda x: format_bytes(x) if x else "—")
            filtered["netout_h"] = filtered["netout"].apply(lambda x: format_bytes(x) if x else "—")

            display_df = filtered[
                ["vmid", "name", "type", "node", "status", "cpu", "mem_pct", "disk_pct", "netin_h", "netout_h"]
            ].copy()
            display_df.columns = [
                "ID", "Nom", "Type", "Nœud", "Statut", "CPU %", "RAM %", "Disque %", "Net ↓ total", "Net ↑ total"
            ]

            st.dataframe(
                display_df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "CPU %": st.column_config.ProgressColumn("CPU %", format="%.1f%%", min_value=0, max_value=100),
                    "RAM %": st.column_config.ProgressColumn("RAM %", format="%.1f%%", min_value=0, max_value=100),
                    "Disque %": st.column_config.ProgressColumn("Disque %", format="%.1f%%", min_value=0, max_value=100),
                },
            )
            st.caption("Net ↓ / ↑ total = volume cumulé depuis le démarrage de la machine (compteurs Proxmox).")

    # ===================== RÉSEAU =====================
    with tab3:
        st.subheader("Trafic réseau")

        st.markdown("#### Débits actuels par nœud")
        net_rows = []
        for n in nodes:
            net_rows.append({
                "Nœud": n["node"],
                "Statut": "🟢" if n["status"] == "online" else "🔴",
                "Download": format_bps(n.get("netin_bps")),
                "Upload": format_bps(n.get("netout_bps")),
                "↓ bytes/s": n.get("netin_bps") or 0,
                "↑ bytes/s": n.get("netout_bps") or 0,
            })
        df_net = pd.DataFrame(net_rows)
        st.dataframe(
            df_net[["Nœud", "Statut", "Download", "Upload"]],
            use_container_width=True,
            hide_index=True,
        )

        if len(df_net) > 0:
            fig_net = go.Figure()
            fig_net.add_trace(go.Bar(
                name="Download",
                x=df_net["Nœud"],
                y=df_net["↓ bytes/s"] * 8 / 1_000_000,  # Mb/s
                marker_color="#3b82f6",
            ))
            fig_net.add_trace(go.Bar(
                name="Upload",
                x=df_net["Nœud"],
                y=df_net["↑ bytes/s"] * 8 / 1_000_000,
                marker_color="#10b981",
            ))
            fig_net.update_layout(
                barmode="group",
                template="plotly_dark",
                height=360,
                yaxis_title="Débit (Mb/s)",
                title="Débit réseau par nœud",
                legend=dict(orientation="h", y=1.12),
            )
            st.plotly_chart(fig_net, use_container_width=True)

        st.markdown("#### Volume cumulé des machines (top 15)")
        if guests:
            gdf = pd.DataFrame(guests)
            gdf["total_net"] = gdf["netin"].fillna(0) + gdf["netout"].fillna(0)
            top = gdf.nlargest(15, "total_net")
            top["↓"] = top["netin"].apply(format_bytes)
            top["↑"] = top["netout"].apply(format_bytes)
            top["Total"] = top["total_net"].apply(format_bytes)
            st.dataframe(
                top[["vmid", "name", "type", "node", "status", "↓", "↑", "Total"]].rename(
                    columns={"vmid": "ID", "name": "Nom", "type": "Type", "node": "Nœud", "status": "Statut"}
                ),
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.info("Aucune machine")

        st.caption(
            "Les débits nœuds proviennent des données RRD Proxmox (moyenne récente). "
            "Les volumes machines sont les compteurs cumulés depuis le démarrage."
        )

    # ===================== STOCKAGE =====================
    with tab4:
        st.subheader("Stockages")
        storages = snapshot["storages"]
        if not storages:
            st.info("Aucun stockage trouvé")
        else:
            for s in storages:
                col1, col2, col3 = st.columns([3, 1, 1])
                active = "✅" if s["active"] else "❌"
                col1.markdown(f"**{s['storage']}** `{s['type']}` — nœud `{s['node']}` {active}")
                col2.metric("Utilisé", format_bytes(s["used"]))
                col3.metric("Total", format_bytes(s["total"]))
                st.progress(min(s["pct"] / 100, 1.0), text=f"{s['pct']:.1f}% utilisé")
                st.divider()

    # ===================== HARDWARE iDRAC =====================
    with tab5:
        st.subheader("Hardware Dell PowerEdge (iDRAC / Redfish)")
        if not idrac_data:
            st.info(
                "Aucun iDRAC configuré. Ajoutez `IDRAC_HOSTS` et `IDRAC_PASSWORD` dans le fichier `.env`."
            )
        else:
            for hw in idrac_data:
                reachable = hw.get("reachable")
                health = hw.get("health") or hw.get("health_rollup") or "?"
                icon = "🟢" if reachable and str(health).upper() in ("OK", "OKAY") else ("🔴" if not reachable else "🟡")
                title = f"{icon} **{hw.get('name')}** — {hw.get('model') or 'PowerEdge'}"
                with st.expander(title, expanded=True):
                    if not reachable:
                        st.error("iDRAC injoignable : " + ", ".join(hw.get("errors") or ["timeout / auth"]))
                        continue

                    m1, m2, m3, m4, m5 = st.columns(5)
                    m1.metric("Santé", str(health))
                    m2.metric("Power", hw.get("power_state") or "—")
                    m3.metric("Conso", f"{hw.get('power_consumed_watts') or '—'} W")
                    m4.metric("S/N", hw.get("serial") or "—")
                    m5.metric("BIOS", hw.get("bios_version") or "—")

                    # Températures
                    temps = hw.get("temperatures") or []
                    if temps:
                        st.markdown("**Températures**")
                        tcols = st.columns(min(4, len(temps)))
                        for i, tmp in enumerate(temps[:8]):
                            with tcols[i % len(tcols)]:
                                st.metric(
                                    tmp.get("name", "Temp")[:24],
                                    f"{tmp.get('celsius')} °C",
                                    delta=None,
                                )

                    # Fans
                    fans = hw.get("fans") or []
                    if fans:
                        st.markdown("**Ventilateurs**")
                        fdf = []
                        for f in fans:
                            fdf.append({
                                "Nom": f.get("name"),
                                "RPM": f.get("rpm"),
                                "Status": f.get("status"),
                                "State": f.get("state"),
                            })
                        st.dataframe(__import__("pandas").DataFrame(fdf), use_container_width=True, hide_index=True)

                    # PSU
                    psus = hw.get("power_supplies") or []
                    if psus:
                        st.markdown("**Alimentations**")
                        pdf = []
                        for psu in psus:
                            pdf.append({
                                "Nom": psu.get("name"),
                                "Status": psu.get("status"),
                                "State": psu.get("state"),
                                "Capacité (W)": psu.get("capacity_watts"),
                                "Tension entrée": psu.get("input_voltage"),
                            })
                        st.dataframe(__import__("pandas").DataFrame(pdf), use_container_width=True, hide_index=True)

                    # Disques
                    drives = hw.get("drives") or []
                    if drives:
                        st.markdown("**Disques**")
                        ddf = []
                        for d in drives:
                            cap = d.get("capacity_bytes")
                            cap_s = f"{cap / (1024**3):.0f} GB" if cap else "—"
                            ddf.append({
                                "Nom": d.get("name"),
                                "Status": d.get("status"),
                                "Type": d.get("media_type"),
                                "Capacité": cap_s,
                                "Failure predicted": "⚠️" if d.get("failure_predicted") else "—",
                            })
                        st.dataframe(__import__("pandas").DataFrame(ddf), use_container_width=True, hide_index=True)

                    mem = hw.get("memory_summary")
                    if mem:
                        st.caption(
                            f"Mémoire : {mem.get('total_gib')} GiB — santé {mem.get('health') or '—'}"
                        )

                    # Logs SEL
                    sel = hw.get("sel_logs") or []
                    if sel:
                        st.markdown(
                            f"**System Event Log (SEL)** — "
                            f"{hw.get('sel_critical_count') or 0} critique(s) récent(s)"
                        )
                        log_rows = []
                        for e in sel[:25]:
                            log_rows.append({
                                "Date": (e.get("created") or "")[:19],
                                "Sévérité": e.get("severity"),
                                "Message": (e.get("message") or "")[:120],
                                "ID": e.get("message_id") or e.get("id") or "",
                            })
                        st.dataframe(
                            pd.DataFrame(log_rows),
                            use_container_width=True,
                            hide_index=True,
                            height=280,
                        )
                    else:
                        st.caption("Aucun log SEL récupéré (droits iDRAC ou firmware).")

            # --- Historique températures / puissance ---
            st.divider()
            st.markdown("#### Historique températures & consommation")
            available = history.get_available_idracs()
            if not available:
                st.info("Pas encore d'historique iDRAC. Les points s'accumulent à chaque rafraîchissement / cycle collecteur.")
            else:
                sel = st.selectbox("Serveur iDRAC", available, key="idrac_hist_sel")
                hist = history.get_idrac_history(sel, hours=history_hours)
                if len(hist) < 2:
                    st.info("Pas assez de points pour un graphique.")
                else:
                    hdf = pd.DataFrame(hist)
                    hdf["timestamp"] = pd.to_datetime(hdf["timestamp"])

                    # Températures
                    fig_t = go.Figure()
                    if hdf["temp_inlet"].notna().any():
                        fig_t.add_trace(go.Scatter(
                            x=hdf["timestamp"], y=hdf["temp_inlet"],
                            name="Inlet / Ambient", line=dict(color="#3b82f6", width=2),
                        ))
                    if hdf["temp_cpu_max"].notna().any():
                        fig_t.add_trace(go.Scatter(
                            x=hdf["timestamp"], y=hdf["temp_cpu_max"],
                            name="CPU max", line=dict(color="#ef4444", width=2),
                        ))
                    if hdf["temp_max"].notna().any():
                        fig_t.add_trace(go.Scatter(
                            x=hdf["timestamp"], y=hdf["temp_max"],
                            name="Max tous capteurs", line=dict(color="#f59e0b", width=2, dash="dot"),
                        ))
                    fig_t.update_layout(
                        title=f"Températures — {sel} ({history_hours}h)",
                        xaxis_title="Heure",
                        yaxis_title="°C",
                        hovermode="x unified",
                        legend=dict(orientation="h", y=1.12),
                        height=380,
                        template="plotly_dark",
                    )
                    st.plotly_chart(fig_t, use_container_width=True)

                    # Puissance
                    if hdf["power_watts"].notna().any():
                        fig_p = go.Figure()
                        fig_p.add_trace(go.Scatter(
                            x=hdf["timestamp"],
                            y=hdf["power_watts"],
                            name="Consommation (W)",
                            line=dict(color="#10b981", width=2),
                            fill="tozeroy",
                        ))
                        fig_p.update_layout(
                            title=f"Consommation électrique — {sel} ({history_hours}h)",
                            xaxis_title="Heure",
                            yaxis_title="Watts",
                            hovermode="x unified",
                            height=340,
                            template="plotly_dark",
                        )
                        st.plotly_chart(fig_p, use_container_width=True)

    # ===================== HISTORIQUE =====================
    with tab6:
        st.subheader("Évolution des ressources")

        available_nodes = history.get_available_nodes()
        if not available_nodes:
            st.info("Pas encore d'historique. Les données s'accumulent à chaque rafraîchissement.")
        else:
            selected_node = st.selectbox("Nœud", available_nodes)
            hist = history.get_node_history(selected_node, hours=history_hours)

            if len(hist) < 2:
                st.info("Pas assez de points de données pour tracer un graphique.")
            else:
                df_hist = pd.DataFrame(hist)
                df_hist["timestamp"] = pd.to_datetime(df_hist["timestamp"])

                fig = go.Figure()
                fig.add_trace(
                    go.Scatter(
                        x=df_hist["timestamp"],
                        y=df_hist["cpu"],
                        name="CPU %",
                        line=dict(color="#3b82f6", width=2),
                    )
                )
                fig.add_trace(
                    go.Scatter(
                        x=df_hist["timestamp"],
                        y=df_hist["mem_pct"],
                        name="RAM %",
                        line=dict(color="#10b981", width=2),
                    )
                )
                fig.add_trace(
                    go.Scatter(
                        x=df_hist["timestamp"],
                        y=df_hist["disk_pct"],
                        name="Disque %",
                        line=dict(color="#f59e0b", width=2),
                    )
                )
                fig.update_layout(
                    title=f"Ressources — {selected_node} (dernières {history_hours}h)",
                    xaxis_title="Heure",
                    yaxis_title="Utilisation (%)",
                    yaxis=dict(range=[0, 100]),
                    hovermode="x unified",
                    legend=dict(orientation="h", y=1.1),
                    height=450,
                    template="plotly_dark",
                )
                st.plotly_chart(fig, use_container_width=True)

                if df_hist["load"].notna().any():
                    fig2 = px.line(
                        df_hist,
                        x="timestamp",
                        y="load",
                        title=f"Load average — {selected_node}",
                        labels={"load": "Load", "timestamp": "Heure"},
                    )
                    fig2.update_layout(template="plotly_dark", height=300)
                    st.plotly_chart(fig2, use_container_width=True)

                # Graphique réseau
                if "netin_bps" in df_hist.columns and df_hist["netin_bps"].notna().any():
                    fig3 = go.Figure()
                    fig3.add_trace(go.Scatter(
                        x=df_hist["timestamp"],
                        y=(df_hist["netin_bps"].fillna(0) * 8 / 1_000_000),
                        name="Download (Mb/s)",
                        line=dict(color="#3b82f6", width=2),
                        fill="tozeroy",
                    ))
                    fig3.add_trace(go.Scatter(
                        x=df_hist["timestamp"],
                        y=(df_hist["netout_bps"].fillna(0) * 8 / 1_000_000),
                        name="Upload (Mb/s)",
                        line=dict(color="#10b981", width=2),
                        fill="tozeroy",
                    ))
                    fig3.update_layout(
                        title=f"Réseau — {selected_node} (dernières {history_hours}h)",
                        xaxis_title="Heure",
                        yaxis_title="Débit (Mb/s)",
                        hovermode="x unified",
                        legend=dict(orientation="h", y=1.1),
                        height=380,
                        template="plotly_dark",
                    )
                    st.plotly_chart(fig3, use_container_width=True)

    # Auto-refresh
    if auto_refresh:
        time.sleep(refresh_interval)
        st.rerun()


if __name__ == "__main__":
    main()
